[app]
# Android build configuration for AETHER DAWN: Hollow Eclipse
# Build with: buildozer android debug
# Release with: buildozer android release

title = Aether Dawn - Hollow Eclipse
package.name = aetherdawn
package.domain = com.aetherdawn
source.dir = .
source.include_exts = py,txt,png,jpg,jpeg,kv,wav,ogg
version = 1.0.0
requirements = python3,pygame
orientation = landscape
fullscreen = 1

# Android
android.api = 35
android.minapi = 23
android.ndk = 27c
android.archs = arm64-v8a,armeabi-v7a
android.accept_sdk_license = True

# App appearance
presplash_color = #050510
icon.filename = %(source.dir)s/icon.png

# No network, storage, camera, microphone, or other permissions are required.

[buildozer]
log_level = 2
warn_on_root = 1
