#!/usr/bin/env python3
"""
AETHER DAWN: Hollow Eclipse
A Doom-style 2.5D (raycasting) anime action shooter made with pygame.

Install :  pip install pygame
Run     :  python aether_dawn.py

CONTROLS
  W A S D ........ move / strafe          Mouse (or <- ->) .... look
  Shift .......... sprint
  Left Click / Space ... Spirit Blast (free, rapid fire)
  1 / Right Click ...... Void Sphere  - a gravity sphere that pulls enemies in, then collapses
  2 / E ................ Mirage Clones - a fan of shadow-clone bolts
  3 / R ................ Limitless Dawn - ULTIMATE (fills as you fight)
  Esc .................. pause
"""
import math
import random
import sys
import types

import pygame

# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------
SW, SH = 1024, 640            # window size
RW, RH = 512, 320             # internal render resolution (scaled up = retro look)
COLW = 2                      # pixel width of each ray column
NRAYS = RW // COLW
FOV = math.radians(66)
TAN = math.tan(FOV / 2)
FOCAL = (RW / 2) / TAN
TEX = 64
MAXD = 30.0
WALLS = set("12345")

# --------------------------------------------------------------------------
# Story
# --------------------------------------------------------------------------
PROLOGUE = [
    "Long ago, the star-goddess Aurelia gave the world a gift: the HEART OF DAWN, a crystal of pure light. "
    "From it, every child was born with a spark of AETHER, the power to shape wind, flame, gravity and shadow.",

    "In the shrine village of Asagiri lived Kaito Hoshino, an orphan whose spark never woke. The villagers "
    "called him Powerless. Kaito only smiled and trained harder than anyone. \"Power isn't what you are given,\" "
    "his teacher, Master Sojun, would say. \"It is what you refuse to let anyone take from the people you love.\"",

    "Then came the night of the HOLLOW ECLIPSE. Ren Kurogane, once Kaito's sworn brother and now the Hollow "
    "Emperor, descended with his Shade Legion. Ren believed light was a lie that had abandoned him when his "
    "family was lost. He shattered the Heart of Dawn into three shards, and darkness swallowed the sky.",

    "Master Sojun fell shielding Kaito from the killing blow. As the old man's light faded, something ancient "
    "answered inside Kaito's chest. His eyes blazed sky-blue. BOUNDLESS AETHER, the rarest spark in a thousand "
    "years, finally awoke.",

    "\"Ren... I will bring the light back. All three shards. And I will bring YOU back too.\" "
    "Kaito Hoshino, the boy they called Powerless, rose to his feet. The fight for dawn begins now.",
]

ENDING = [
    "Ren's darkness shatters like glass. Kaito catches his brother as the Hollow Crown crumbles to dust. "
    "\"You... never gave up on me,\" Ren whispers.",

    "The three shards rise and fuse. Dawn breaks over Asagiri for the first time in a hundred nights. "
    "The villagers awaken from the shadow, and the sky blooms gold.",

    "Ren kneels before the reborn Heart of Dawn, tears falling. \"I have so much to atone for.\" "
    "Kaito offers his hand. \"Then we'll do it together.\"",

    "The boy once called Powerless became the hero of a thousand songs, yet he never said it was his power "
    "that won. \"It was never the technique,\" Kaito would say, watching the sunrise. "
    "\"It was refusing to let go of the people I love.\"      -  THE END  -",
]

# --------------------------------------------------------------------------
# Levels   (# = wall types 1-5 | P start | E wraith | A archer | B boss | H heal | K energy | X portal)
# --------------------------------------------------------------------------
LEVELS = [
    dict(
        name="Chapter 1: The Ashen Shrine", sky=0,
        intro=["Asagiri smolders. Beyond the torii gates, the first shard of the Heart of Dawn pulses weakly. "
               "Shade Wraiths, hollow echoes of stolen hearts, haunt the shrine grounds.\n\n"
               "OBJECTIVE: Defeat every shade, then step into the light portal."],
        start=("Kaito", "Master... lend me your strength. Let's take back the first shard!"),
        clear=("Kaito", "The portal is open! The shard's light is calling me."),
        map=[
            "1111111111111111111111",
            "1P...1.......1.......1",
            "1....1..E....1...A...1",
            "1....2.......2.......1",
            "1..H.......E.......K.1",
            "1....1.......1.......1",
            "1....1...E...1..E....1",
            "1....1.......1.......1",
            "1111.11111.1111111.111",
            "1....................1",
            "1..E..............E..1",
            "1111.11111.1111111.111",
            "1......1.......1.....1",
            "1..E...1...A...1..E..1",
            "1......2.......2.....1",
            "1......1.......1..X..1",
            "1111111111111111111111",
        ]),
    dict(
        name="Chapter 2: Fortress of Whispering Shadows", sky=1,
        intro=["The shard's glow leads Kaito into Ren's fortress, where crystal pillars hum with stolen light. "
               "Ren's voice echoes down the halls: \"Why do you keep fighting, Kaito? Light abandons everyone "
               "in the end.\"\n\nOBJECTIVE: Cut through the Shadow Legion and reach the portal."],
        start=("Ren", "Why keep fighting, Kaito? Light abandons everyone in the end."),
        clear=("Kaito", "Two shards down. Ren... I'm coming for you."),
        map=[
            "11111111111111111111",
            "1P.....3.....3.....1",
            "1......3..A..3..E..1",
            "1......3.....3.....1",
            "1..................1",
            "1..4...E...4...E...1",
            "1..................1",
            "1..4...A...4...A...1",
            "1..................1",
            "1111.11111111.111111",
            "1.....3.......3....1",
            "1..E..3...E....A...1",
            "1.....3.......3....1",
            "1..K..3...H...3..X.1",
            "1..E..3.......3.E..1",
            "11111111111111111111",
        ]),
    dict(
        name="Chapter 3: Throne of Eclipse", sky=2,
        intro=["Two shards blaze in Kaito's hands. At the far end of the hall waits Ren, the Hollow Emperor, "
               "crowned in living darkness.\n\n\"This ends tonight, brother.\"\n\n"
               "OBJECTIVE: Defeat the Hollow Emperor. Save the dawn."],
        start=("Ren", "You came all this way, brother. Show me the power you awakened."),
        clear=("Kaito", "It's over, Ren."),
        map=[
            "11111111111111111111",
            "1........B.........1",
            "1..5....E....E..5..1",
            "1..................1",
            "1...4..........4...1",
            "1H................K1",
            "1..5....A....A..5..1",
            "1..................1",
            "1...4..........4...1",
            "1K................H1",
            "1..5....E....E..5..1",
            "1..................1",
            "1........P.........1",
            "11111111111111111111",
        ]),
]

SKIES = [
    dict(top=(8, 6, 28), bot=(150, 60, 60), moon=(255, 235, 205), eclipse=False, floor=(46, 36, 40)),
    dict(top=(12, 4, 30), bot=(90, 30, 120), moon=(185, 200, 255), eclipse=False, floor=(30, 22, 46)),
    dict(top=(0, 0, 0), bot=(110, 0, 25), moon=(15, 0, 8), eclipse=True, floor=(40, 12, 22)),
]

# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------
def clampc(c):
    return tuple(max(0, min(255, int(v))) for v in c)


# --------------------------------------------------------------------------
# Android touch controls
# --------------------------------------------------------------------------
class TouchKeys:
    """Keyboard-compatible view of virtual mobile controls."""
    def __init__(self):
        self.forward = self.back = self.left = self.right = False
        self.sprint = False

    def __getitem__(self, key):
        if key in (pygame.K_w, pygame.K_UP):
            return self.forward
        if key == pygame.K_s or key == pygame.K_DOWN:
            return self.back
        if key == pygame.K_a:
            return self.left
        if key == pygame.K_d:
            return self.right
        if key in (pygame.K_LSHIFT, pygame.K_RSHIFT):
            return self.sprint
        if key in (pygame.K_LEFT, pygame.K_RIGHT):
            return False
        return False


class TouchControls:
    """Landscape virtual joystick + camera pad + ability buttons."""
    def __init__(self, width=SW, height=SH):
        self.w, self.h = width, height
        self.keys = TouchKeys()
        self.firing = False
        self.look_delta = 0.0
        self.pointer = {}
        self.joy_id = None
        self.joy_center = (105, height - 115)
        self.joy_radius = 72
        self.joy_knob = self.joy_center
        self.look_ids = set()
        self.buttons = {}
        self.refresh(width, height)

    def refresh(self, width, height):
        self.w, self.h = width, height
        self.joy_center = (105, height - 115)
        self.buttons = {
            "blast": pygame.Rect(width - 150, height - 105, 62, 62),
            "sphere": pygame.Rect(width - 225, height - 175, 62, 62),
            "mirage": pygame.Rect(width - 150, height - 180, 62, 62),
            "ult": pygame.Rect(width - 75, height - 175, 62, 62),
            "sprint": pygame.Rect(22, height - 195, 58, 40),
            "pause": pygame.Rect(width - 62, 18, 44, 38),
        }

    def pos(self, event):
        if hasattr(event, "pos"):
            return event.pos
        return int(event.x * self.w), int(event.y * self.h)

    def touch_down(self, tid, pos):
        x, y = pos
        self.pointer[tid] = (x, y)
        if self.buttons["blast"].collidepoint(x, y):
            self.firing = True
            return "blast"
        for name in ("sphere", "mirage", "ult"):
            if self.buttons[name].collidepoint(x, y):
                return name
        if self.buttons["pause"].collidepoint(x, y):
            return "pause"
        if self.buttons["sprint"].collidepoint(x, y):
            self.keys.sprint = True
            return "sprint"
        if x < self.w * 0.42 and y > self.h * 0.55 and self.joy_id is None:
            self.joy_id = tid
            self.update_joystick(pos)
            return "joystick"
        if x > self.w * 0.45:
            self.look_ids.add(tid)
            return "look"
        return None

    def update_joystick(self, pos):
        cx, cy = self.joy_center
        dx, dy = pos[0] - cx, pos[1] - cy
        d = math.hypot(dx, dy) or 1.0
        if d > self.joy_radius:
            dx, dy = dx / d * self.joy_radius, dy / d * self.joy_radius
        self.joy_knob = (cx + dx, cy + dy)
        nx, ny = dx / self.joy_radius, dy / self.joy_radius
        self.keys.forward = ny < -0.22
        self.keys.back = ny > 0.22
        self.keys.left = nx < -0.22
        self.keys.right = nx > 0.22

    def touch_motion(self, tid, pos):
        old = self.pointer.get(tid)
        self.pointer[tid] = pos
        if tid == self.joy_id:
            self.update_joystick(pos)
            return 0.0
        if tid in self.look_ids and old:
            dx = pos[0] - old[0]
            self.look_delta += dx
            return dx
        return 0.0

    def touch_up(self, tid):
        self.pointer.pop(tid, None)
        if tid == self.joy_id:
            self.joy_id = None
            self.joy_knob = self.joy_center
            self.keys.forward = self.keys.back = self.keys.left = self.keys.right = False
        self.look_ids.discard(tid)
        if not any(self.buttons["blast"].collidepoint(*p) for p in self.pointer.values()):
            self.firing = False
        if not any(self.buttons["sprint"].collidepoint(*p) for p in self.pointer.values()):
            self.keys.sprint = False

    def draw(self, scr, font):
        # translucent joystick
        pygame.draw.circle(scr, (20, 30, 55, 150), self.joy_center, self.joy_radius, 3)
        pygame.draw.circle(scr, (100, 180, 255, 95), (int(self.joy_knob[0]), int(self.joy_knob[1])), 28)
        labels = {"blast":"BLAST", "sphere":"VOID", "mirage":"MIRAGE", "ult":"DAWN", "sprint":"RUN", "pause":"II"}
        for name, rect in self.buttons.items():
            fill = (20, 25, 50, 175)
            pygame.draw.rect(scr, fill, rect, border_radius=10)
            pygame.draw.rect(scr, (130, 205, 255), rect, 2, border_radius=10)
            txt = font.render(labels[name], True, (245, 245, 255))
            scr.blit(txt, txt.get_rect(center=rect.center))


def lerp(a, b, k):
    return tuple(a[i] + (b[i] - a[i]) * k for i in range(3))


def wrap(font, text, width):
    lines = []
    for para in text.split("\n"):
        cur = ""
        for w in para.split(" "):
            t = (cur + " " + w).strip()
            if font.size(t)[0] <= width:
                cur = t
            else:
                lines.append(cur)
                cur = w
        lines.append(cur)
    return lines


def make_glow(color, size=64):
    g = pygame.Surface((size, size), pygame.SRCALPHA)
    for i in range(size // 2, 0, -1):
        a = int(255 * (1 - i / (size / 2)) ** 1.6)
        pygame.draw.circle(g, (*color, a), (size // 2, size // 2), i)
    return g


# --------------------------------------------------------------------------
# Procedural textures & sprites (no external assets needed)
# --------------------------------------------------------------------------
def brick_tex(base, mortar, seed, glow=None):
    r = random.Random(seed)
    s = pygame.Surface((TEX, TEX))
    s.fill(mortar)
    for row in range(4):
        off = 16 if row % 2 else 0
        for bx in range(-1, 3):
            c = clampc([v + r.randint(-16, 16) for v in base])
            x, y = bx * 32 + off + 1, row * 16 + 1
            pygame.draw.rect(s, c, (x, y, 30, 14))
            pygame.draw.line(s, clampc([v + 28 for v in c]), (x, y), (x + 29, y))
    if glow:
        for _ in range(4):
            pygame.draw.circle(s, glow, (r.randint(6, 56), r.randint(6, 56)), 2)
    return s


def plank_tex():
    s = pygame.Surface((TEX, TEX))
    s.fill((150, 28, 34))
    for x in range(0, TEX, 16):
        pygame.draw.line(s, (90, 14, 20), (x, 0), (x, TEX), 2)
    pygame.draw.rect(s, (230, 190, 70), (0, 26, TEX, 10))
    pygame.draw.rect(s, (150, 110, 30), (0, 26, TEX, 10), 1)
    return s


def crystal_tex():
    s = pygame.Surface((TEX, TEX))
    for y in range(TEX):
        pygame.draw.line(s, lerp((30, 60, 160), (120, 220, 255), y / TEX), (0, y), (TEX, y))
    for i in range(-TEX, TEX, 14):
        pygame.draw.line(s, (200, 245, 255), (i, TEX), (i + TEX, 0), 1)
    return s


def obsidian_tex():
    r = random.Random(9)
    s = pygame.Surface((TEX, TEX))
    s.fill((16, 12, 24))
    for _ in range(9):
        x, y = r.randint(0, TEX), r.randint(0, TEX)
        pygame.draw.line(s, (120, 40, 170), (x, y), (x + r.randint(-20, 20), y + r.randint(-20, 20)), 1)
    return s


def make_sprite(kind):
    s = pygame.Surface((64, 64), pygame.SRCALPHA)
    if kind in ("wraith", "archer"):
        body = (38, 22, 58) if kind == "wraith" else (18, 40, 56)
        edge = (140, 80, 210) if kind == "wraith" else (70, 190, 200)
        pts = [(32, 4), (48, 16), (55, 58), (46, 53), (40, 61), (32, 54), (24, 61), (18, 53), (9, 58), (16, 16)]
        pygame.draw.polygon(s, body, pts)
        pygame.draw.polygon(s, edge, pts, 2)
        pygame.draw.ellipse(s, (232, 232, 240), (23, 12, 18, 22))          # mask
        pygame.draw.ellipse(s, (255, 40, 60), (26, 21, 4, 6))              # eyes
        pygame.draw.ellipse(s, (255, 40, 60), (34, 21, 4, 6))
        pygame.draw.line(s, (60, 20, 40), (28, 30), (36, 30), 1)
        if kind == "archer":
            pygame.draw.arc(s, (220, 220, 240), (4, 22, 20, 30), -1.4, 1.4, 2)
            pygame.draw.line(s, (220, 220, 240), (16, 24), (16, 50), 1)
    elif kind == "boss":                                                    # Ren, the Hollow Emperor
        s.blit(make_glow((170, 40, 220)), (0, 0))
        pygame.draw.polygon(s, (14, 8, 24), [(32, 14), (56, 26), (60, 62), (4, 62), (8, 26)])       # cloak
        pygame.draw.polygon(s, (190, 20, 50), [(32, 14), (56, 26), (60, 62), (4, 62), (8, 26)], 2)
        pygame.draw.polygon(s, (14, 8, 24), [(14, 22), (32, 34), (50, 22), (54, 10), (10, 10)])      # collar
        pygame.draw.polygon(s, (235, 235, 245), [(18, 8), (24, 40), (30, 18)])                       # white hair
        pygame.draw.polygon(s, (235, 235, 245), [(46, 8), (40, 40), (34, 18)])
        pygame.draw.ellipse(s, (230, 220, 225), (24, 12, 16, 22))                                    # face
        pygame.draw.ellipse(s, (255, 30, 50), (27, 21, 4, 5))
        pygame.draw.ellipse(s, (255, 30, 50), (34, 21, 4, 5))
        for hx in (18, 26, 38, 46):                                                                  # crown horns
            pygame.draw.polygon(s, (30, 10, 40), [(hx, 12), (hx + 3, 12), (hx + 1, 0)])
        pygame.draw.circle(s, (200, 60, 255), (32, 44), 4)
    elif kind == "heart":
        pygame.draw.circle(s, (255, 70, 110), (24, 26), 10)
        pygame.draw.circle(s, (255, 70, 110), (40, 26), 10)
        pygame.draw.polygon(s, (255, 70, 110), [(15, 30), (49, 30), (32, 52)])
        pygame.draw.circle(s, (255, 200, 220), (21, 23), 3)
    elif kind == "orb":
        s.blit(make_glow((80, 200, 255)), (0, 0))
        pygame.draw.circle(s, (210, 245, 255), (32, 32), 8)
    elif kind == "portal":
        for i, col in enumerate([(80, 180, 255), (180, 240, 255), (255, 255, 255)]):
            pygame.draw.ellipse(s, col, (6 + i * 7, 2 + i * 4, 52 - i * 14, 60 - i * 8), 3)
        s.blit(make_glow((160, 220, 255)), (0, 0), special_flags=pygame.BLEND_RGBA_MAX)
    return s


def make_proj_sprite(color):
    s = make_glow(color)
    pygame.draw.circle(s, (255, 255, 255), (32, 32), 6)
    return s


def make_sky(p):
    w, h = int(RW * 360 / 66), RH // 2
    s = pygame.Surface((w, h))
    for y in range(h):
        pygame.draw.line(s, lerp(p["top"], p["bot"], (y / h) ** 1.4), (0, y), (w, y))
    r = random.Random(4)
    for _ in range(420):
        b = r.randint(120, 255)
        s.set_at((r.randrange(w), r.randrange(int(h * 0.85))), (b, b, b))
    mx, my = int(w * 0.30), int(h * 0.42)
    if p["eclipse"]:
        for rad, col in ((60, (60, 0, 12)), (50, (140, 10, 30)), (42, (255, 80, 60))):
            pygame.draw.circle(s, col, (mx, my), rad)
        pygame.draw.circle(s, (0, 0, 0), (mx, my), 38)
    else:
        pygame.draw.circle(s, lerp(p["moon"], p["bot"], 0.6), (mx, my), 46)
        pygame.draw.circle(s, p["moon"], (mx, my), 34)
    return s


def make_floor(p):
    h = RH - RH // 2
    s = pygame.Surface((RW, h))
    for y in range(h):
        k = y / h
        pygame.draw.line(s, lerp((6, 4, 10), p["floor"], k ** 0.8), (0, y), (RW, y))
    return s


# --------------------------------------------------------------------------
# Game objects
# --------------------------------------------------------------------------
class Enemy:
    STATS = {"wraith": (40, 1.7, 0.32, 0.9), "archer": (30, 1.2, 0.32, 0.9), "boss": (500, 1.5, 0.55, 1.7)}

    def __init__(self, kind, x, y):
        self.kind, self.x, self.y = kind, x, y
        self.hp, self.spd, self.r, self.scale = Enemy.STATS[kind]
        self.maxhp = self.hp
        self.cd = random.uniform(0.4, 1.4)
        self.hurt = 0.0
        self.t = random.random() * 9
        self.aware = False
        self.dead = False
        self.summon = 9.0
        self.phase2 = False


PROJ = {
    "blast":  dict(spd=17, dmg=14, r=0.20, life=1.6, col=(90, 200, 255), own="p"),
    "sphere": dict(spd=6,  dmg=0,  r=0.35, life=2.4, col=(150, 110, 255), own="p"),
    "mirage": dict(spd=15, dmg=12, r=0.20, life=1.0, col=(255, 170, 60), own="p"),
    "shade":  dict(spd=6.5, dmg=10, r=0.20, life=4.0, col=(255, 70, 170), own="e"),
}


class Game:
    def __init__(self, screen):
        self.screen = screen
        self.view = pygame.Surface((RW, RH))
        self.depth = [MAXD] * NRAYS
        self.f_s = pygame.font.Font(None, 22)
        self.f_m = pygame.font.Font(None, 30)
        self.f_l = pygame.font.Font(None, 64)
        self.tex = {"1": brick_tex((120, 118, 132), (52, 50, 62), 1), "2": plank_tex(),
                    "3": brick_tex((72, 46, 98), (26, 16, 40), 3, glow=(210, 100, 255)),
                    "4": crystal_tex(), "5": obsidian_tex()}
        self.spr = {k: make_sprite(k) for k in ("wraith", "archer", "boss", "heart", "orb", "portal")}
        for k, v in PROJ.items():
            self.spr[k] = make_proj_sprite(v["col"])
        self.glows = {}
        self.skies = [make_sky(p) for p in SKIES]
        self.floors = [make_floor(p) for p in SKIES]
        self.pl = types.SimpleNamespace(x=1.5, y=1.5, a=0.0)
        self.hp = 100.0
        self.load_level(0)

    # ---------------------------------------------------------------- level
    def load_level(self, idx):
        self.idx = idx
        L = LEVELS[idx]
        rows = L["map"]
        self.mh = len(rows)
        self.mw = max(len(r) for r in rows)
        self.grid = [list(r.ljust(self.mw, "1")) for r in rows]
        self.enemies, self.pickups, self.projs, self.effects = [], [], [], []
        self.portal = None
        for y, row in enumerate(self.grid):
            for x, ch in enumerate(row):
                cx, cy = x + 0.5, y + 0.5
                if ch == "P":
                    self.pl.x, self.pl.y = cx, cy
                elif ch == "E":
                    self.enemies.append(Enemy("wraith", cx, cy))
                elif ch == "A":
                    self.enemies.append(Enemy("archer", cx, cy))
                elif ch == "B":
                    self.enemies.append(Enemy("boss", cx, cy))
                elif ch == "H":
                    self.pickups.append(dict(x=cx, y=cy, kind="heart"))
                elif ch == "K":
                    self.pickups.append(dict(x=cx, y=cy, kind="orb"))
                elif ch == "X":
                    self.portal = (cx, cy)
                if ch not in WALLS:
                    row[x] = "."
        self.pl.a = 0.0 if idx < 2 else -math.pi / 2
        self.hp = min(100.0, max(self.hp, 60.0)) if idx else 100.0
        if self.hp < 100:
            self.hp = min(100.0, self.hp + 30)
        self.energy, self.awk = 100.0, 0.0
        self.cd = dict(blast=0.0, sphere=0.0, mirage=0.0)
        self.kills, self.walk, self.recoil = 0, 0.0, 0.0
        self.dmg_flash = self.ult_flash = 0.0
        self.state, self.cleared, self.win_timer = "play", False, 0.0
        self.flags = set()
        self.msg = None
        self.banner = None
        self.sky, self.floor = self.skies[L["sky"]], self.floors[L["sky"]]
        self.say(*L["start"], dur=5.5)

    def retry(self):
        self.hp = 100.0
        self.load_level(self.idx)

    def cell(self, x, y):
        if 0 <= x < self.mw and 0 <= y < self.mh:
            return self.grid[y][x]
        return "1"

    def free(self, x, y, r):
        for ox, oy in ((-r, -r), (r, -r), (-r, r), (r, r)):
            if self.cell(int(math.floor(x + ox)), int(math.floor(y + oy))) in WALLS:
                return False
        return True

    def try_move(self, e, dx, dy, r):
        if self.free(e.x + dx, e.y, r):
            e.x += dx
        if self.free(e.x, e.y + dy, r):
            e.y += dy

    def los(self, x1, y1, x2, y2):
        d = math.hypot(x2 - x1, y2 - y1)
        n = max(1, int(d / 0.25))
        for i in range(1, n):
            k = i / n
            if self.cell(int(x1 + (x2 - x1) * k), int(y1 + (y2 - y1) * k)) in WALLS:
                return False
        return True

    def glow(self, col):
        if col not in self.glows:
            self.glows[col] = make_glow(col)
        return self.glows[col]

    def say(self, who, text, dur=4.5):
        self.msg = [who, text, dur]

    def call(self, text, dur=1.4):
        self.banner = [text, dur, dur]

    def fx(self, x, y, col, dur=0.5, size=1.0, grow=1.6):
        self.effects.append(dict(x=x, y=y, t=0.0, dur=dur, col=col, size=size, grow=grow))

    # ---------------------------------------------------------------- powers
    def fire(self, kind, ang, x=None, y=None, owner=None):
        d = PROJ[kind]
        x = self.pl.x if x is None else x
        y = self.pl.y if y is None else y
        self.projs.append(dict(kind=kind, x=x, y=y, vx=math.cos(ang) * d["spd"], vy=math.sin(ang) * d["spd"],
                               dmg=d["dmg"], r=d["r"], life=d["life"], own=d["own"]))

    def cast_blast(self):
        if self.state != "play" or self.cd["blast"] > 0:
            return
        self.cd["blast"] = 0.16
        self.recoil = 0.12
        self.fire("blast", self.pl.a)

    def cast_sphere(self):
        if self.state != "play" or self.cd["sphere"] > 0 or self.energy < 30:
            return
        self.energy -= 30
        self.cd["sphere"] = 1.2
        self.recoil = 0.3
        self.fire("sphere", self.pl.a)
        self.call("VOID SPHERE: GRAVITY COLLAPSE")

    def cast_mirage(self):
        if self.state != "play" or self.cd["mirage"] > 0 or self.energy < 25:
            return
        self.energy -= 25
        self.cd["mirage"] = 0.9
        self.recoil = 0.25
        for k in range(-3, 4):
            self.fire("mirage", self.pl.a + k * 0.09)
        self.call("MIRAGE CLONES!")

    def cast_ult(self):
        if self.state != "play":
            return
        if self.awk < 100:
            self.say("Kaito", "The Awakening isn't ready yet... keep fighting!", 2.5)
            return
        self.awk = 0
        self.ult_flash = 1.0
        self.hp = min(100, self.hp + 25)
        self.call("LIMITLESS DAWN!!", 2.0)
        for e in self.enemies:
            if not e.dead and math.hypot(e.x - self.pl.x, e.y - self.pl.y) < 14:
                self.fx(e.x, e.y, (255, 240, 180), 0.9, 1.6, 2.0)
                self.damage(e, 150 if e.kind == "boss" else 120)

    def explode(self, x, y):
        self.fx(x, y, (170, 130, 255), 0.7, 1.4, 3.0)
        for e in self.enemies:
            if e.dead:
                continue
            d = math.hypot(e.x - x, e.y - y)
            if d < 3.4:
                self.damage(e, 20 + 55 * (1 - d / 3.4))

    def damage(self, e, dmg):
        if e.dead:
            return
        e.hp -= dmg
        e.hurt = 0.12
        e.aware = True
        self.awk = min(100, self.awk + dmg * 0.05)
        if e.kind == "boss" and e.hp < e.maxhp * 0.25 and "boss25" not in self.flags:
            self.flags.add("boss25")
            self.say("Kaito", "I won't give up on you, Ren!", 3.5)
        if e.hp <= 0:
            e.dead = True
            self.kills += 1
            self.awk = min(100, self.awk + 14)
            self.fx(e.x, e.y, (190, 90, 255), 0.6, 1.2, 2.0)
            if e.kind == "boss":
                for o in self.enemies:
                    if not o.dead:
                        o.dead = True
                        self.fx(o.x, o.y, (190, 90, 255), 0.6, 1.2, 2.0)

    def hurt_player(self, dmg):
        self.hp -= dmg
        self.dmg_flash = 0.35
        if self.hp <= 0 and self.state == "play":
            self.hp = 0
            self.state = "dead"

    # ---------------------------------------------------------------- update
    def update(self, dt, keys, rel, firing):
        if self.msg:
            self.msg[2] -= dt
            if self.msg[2] <= 0:
                self.msg = None
        if self.banner:
            self.banner[1] -= dt
            if self.banner[1] <= 0:
                self.banner = None
        for f in self.effects:
            f["t"] += dt
        self.effects = [f for f in self.effects if f["t"] < f["dur"]]
        self.dmg_flash = max(0, self.dmg_flash - dt)
        self.ult_flash = max(0, self.ult_flash - dt * 1.4)
        self.recoil = max(0, self.recoil - dt)
        if self.state == "dead":
            return
        if self.state == "clear":
            return

        p = self.pl
        for k in self.cd:
            self.cd[k] = max(0, self.cd[k] - dt)
        self.energy = min(100, self.energy + 9 * dt)

        # ---- movement (WASD + mouse look)
        p.a += (int(bool(keys[pygame.K_RIGHT])) - int(bool(keys[pygame.K_LEFT]))) * 2.4 * dt + rel * 0.0025
        c, sn = math.cos(p.a), math.sin(p.a)
        f = int(bool(keys[pygame.K_w] or keys[pygame.K_UP])) - int(bool(keys[pygame.K_s] or keys[pygame.K_DOWN]))
        st = int(bool(keys[pygame.K_d])) - int(bool(keys[pygame.K_a]))
        if f or st:
            mx, my = c * f - sn * st, sn * f + c * st
            ln = math.hypot(mx, my)
            spd = 3.4 * (1.7 if (keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]) else 1.0)
            self.try_move(p, mx / ln * spd * dt, my / ln * spd * dt, 0.22)
            self.walk += dt * spd * 2.2
        if firing:
            self.cast_blast()

        # ---- pickups
        for pk in self.pickups[:]:
            if math.hypot(pk["x"] - p.x, pk["y"] - p.y) < 0.6:
                if pk["kind"] == "heart" and self.hp < 100:
                    self.hp = min(100, self.hp + 35)
                    self.pickups.remove(pk)
                elif pk["kind"] == "orb" and self.energy < 100:
                    self.energy = min(100, self.energy + 60)
                    self.pickups.remove(pk)

        # ---- enemies & projectiles
        for e in self.enemies:
            if not e.dead:
                self.update_enemy(e, dt)
        self.update_projectiles(dt)

        # ---- objectives
        alive = [e for e in self.enemies if not e.dead]
        if not alive and not self.cleared:
            self.cleared = True
            self.say(*LEVELS[self.idx]["clear"], dur=5)
        if self.cleared:
            if self.portal:
                if math.hypot(self.portal[0] - p.x, self.portal[1] - p.y) < 0.9:
                    self.state = "clear"
            else:
                self.win_timer += dt
                if self.win_timer > 2.5:
                    self.state = "clear"

    def update_enemy(self, e, dt):
        e.t += dt
        e.hurt = max(0, e.hurt - dt)
        e.cd -= dt
        p = self.pl
        dx, dy = p.x - e.x, p.y - e.y
        d = math.hypot(dx, dy) or 1e-6
        ux, uy = dx / d, dy / d
        seen = self.los(e.x, e.y, p.x, p.y)
        if not e.aware:
            if seen and d < 14:
                e.aware = True
            else:
                return
        sp = e.spd * dt
        if e.kind == "wraith":
            if d > 0.7:
                self.try_move(e, ux * sp, uy * sp, e.r)
            if d < 1.0 and e.cd <= 0:
                self.hurt_player(8)
                e.cd = 0.9
        elif e.kind == "archer":
            if d > 7:
                self.try_move(e, ux * sp, uy * sp, e.r)
            elif d < 4:
                self.try_move(e, -ux * sp, -uy * sp, e.r)
            else:
                s = 1 if math.sin(e.t * 0.9) > 0 else -1
                self.try_move(e, -uy * sp * s, ux * sp * s, e.r)
            if seen and e.cd <= 0 and d < 13:
                self.fire("shade", math.atan2(dy, dx), e.x, e.y)
                e.cd = 1.8
        else:  # boss: Ren, the Hollow Emperor
            if not e.phase2 and e.hp < e.maxhp * 0.5:
                e.phase2 = True
                self.say("Ren", "Enough! Drown in the HOLLOW ECLIPSE!", 4)
                self.fx(e.x, e.y, (255, 40, 90), 1.0, 2.0, 3.0)
            sp *= 1.35 if e.phase2 else 1.0
            if d > 6:
                self.try_move(e, ux * sp, uy * sp, e.r)
            elif d < 3.5:
                self.try_move(e, -ux * sp, -uy * sp, e.r)
            else:
                s = 1 if math.sin(e.t * 0.7) > 0 else -1
                self.try_move(e, -uy * sp * s, ux * sp * s, e.r)
            if seen and e.cd <= 0:
                n = 5 if e.phase2 else 3
                base = math.atan2(dy, dx)
                for k in range(n):
                    self.fire("shade", base + (k - (n - 1) / 2) * 0.17, e.x, e.y)
                e.cd = 1.1 if e.phase2 else 1.7
            e.summon -= dt
            if e.summon <= 0:
                e.summon = 14
                if sum(1 for o in self.enemies if not o.dead and o.kind == "wraith") < 5:
                    for ox in (-1, 1):
                        if self.free(e.x + ox, e.y, 0.35):
                            self.enemies.append(Enemy("wraith", e.x + ox, e.y))
                            self.enemies[-1].aware = True
                            self.fx(e.x + ox, e.y, (190, 90, 255), 0.5, 1.0, 1.5)

    def update_projectiles(self, dt):
        p = self.pl
        for pr in self.projs:
            pr["life"] -= dt
            for _ in range(2):
                ox, oy = pr["x"], pr["y"]
                pr["x"] += pr["vx"] * dt / 2
                pr["y"] += pr["vy"] * dt / 2
                if self.cell(int(math.floor(pr["x"])), int(math.floor(pr["y"]))) in WALLS:
                    pr["x"], pr["y"] = ox, oy
                    pr["life"] = 0
                    break
                if pr["own"] == "p":
                    if pr["kind"] == "sphere":
                        for e in self.enemies:
                            if not e.dead:
                                ex, ey = pr["x"] - e.x, pr["y"] - e.y
                                dd = math.hypot(ex, ey)
                                if 0.5 < dd < 4.0:
                                    self.try_move(e, ex / dd * 3.2 * dt / 2, ey / dd * 3.2 * dt / 2, e.r)
                    for e in self.enemies:
                        if not e.dead and math.hypot(e.x - pr["x"], e.y - pr["y"]) < e.r + pr["r"]:
                            if pr["kind"] != "sphere":
                                self.damage(e, pr["dmg"])
                                self.fx(pr["x"], pr["y"], pr["kind"] == "mirage" and (255, 170, 60) or (90, 200, 255), 0.25, 0.5, 1.0)
                            pr["life"] = 0
                            break
                elif math.hypot(p.x - pr["x"], p.y - pr["y"]) < 0.35:
                    self.hurt_player(pr["dmg"])
                    pr["life"] = 0
                if pr["life"] <= 0:
                    break
            if pr["life"] <= 0:
                if pr["kind"] == "sphere":
                    self.explode(pr["x"], pr["y"])
                else:
                    self.fx(pr["x"], pr["y"], PROJ[pr["kind"]]["col"], 0.2, 0.4, 1.0)
        self.projs = [q for q in self.projs if q["life"] > 0]

    # ---------------------------------------------------------------- render
    def render(self):
        v, p = self.view, self.pl
        off = int((p.a % (2 * math.pi)) / (2 * math.pi) * self.sky.get_width())
        v.blit(self.sky, (-off, 0))
        v.blit(self.sky, (self.sky.get_width() - off, 0))
        v.blit(self.floor, (0, RH // 2))
        self.cast_walls()
        self.draw_sprites()
        self.draw_hand()

    def cast_walls(self):
        v, p = self.view, self.pl
        dx, dy = math.cos(p.a), math.sin(p.a)
        plx, ply = -dy * TAN, dx * TAN
        for i in range(NRAYS):
            cam = 2 * i / NRAYS - 1
            rdx, rdy = dx + plx * cam, dy + ply * cam
            mx, my = int(math.floor(p.x)), int(math.floor(p.y))
            ddx = abs(1 / rdx) if rdx else 1e30
            ddy = abs(1 / rdy) if rdy else 1e30
            if rdx < 0:
                stx, sdx = -1, (p.x - mx) * ddx
            else:
                stx, sdx = 1, (mx + 1 - p.x) * ddx
            if rdy < 0:
                sty, sdy = -1, (p.y - my) * ddy
            else:
                sty, sdy = 1, (my + 1 - p.y) * ddy
            side, hit = 0, "1"
            for _ in range(64):
                if sdx < sdy:
                    sdx += ddx
                    mx += stx
                    side = 0
                else:
                    sdy += ddy
                    my += sty
                    side = 1
                c = self.cell(mx, my)
                if c in WALLS:
                    hit = c
                    break
            perp = max(0.05, (sdx - ddx) if side == 0 else (sdy - ddy))
            self.depth[i] = perp
            wx = (p.y + perp * rdy) if side == 0 else (p.x + perp * rdx)
            wx -= math.floor(wx)
            tx = int(wx * TEX)
            if (side == 0 and rdx > 0) or (side == 1 and rdy < 0):
                tx = TEX - 1 - tx
            tx = max(0, min(TEX - 1, tx))
            h = int(FOCAL / perp)
            tex = self.tex[hit]
            if h > RH:
                cut = int((h - RH) / 2 / h * TEX)
                src = tex.subsurface((tx, cut, 1, max(1, TEX - 2 * cut)))
                col = pygame.transform.scale(src, (COLW, RH))
                top = 0
            else:
                col = pygame.transform.scale(tex.subsurface((tx, 0, 1, TEX)), (COLW, max(1, h)))
                top = RH // 2 - h // 2
            shade = max(0.12, 1.0 / (1.0 + perp * 0.16)) * (0.72 if side else 1.0)
            b = int(255 * shade)
            col.fill((b, b, b), special_flags=pygame.BLEND_RGB_MULT)
            v.blit(col, (i * COLW, top))

    def billboard(self, surf, wx, wy, scale=1.0, anchor="floor", alpha=255, flash=False, hover=0.0):
        p = self.pl
        dx, dy = wx - p.x, wy - p.y
        c, sn = math.cos(p.a), math.sin(p.a)
        depth = dx * c + dy * sn
        if depth < 0.3:
            return
        side = (dy * c - dx * sn) / TAN
        sx = RW / 2 * (1 + side / depth)
        size = FOCAL / depth
        h = int(size * scale)
        if h < 2 or h > 900:
            return
        top = int(RH / 2 + size / 2 - h - hover * size) if anchor == "floor" else int(RH / 2 - h / 2 - hover * size)
        left = int(sx - h / 2)
        if left > RW or left + h < 0:
            return
        img = pygame.transform.scale(surf, (h, h))
        b = int(255 * max(0.25, 1.0 / (1.0 + depth * 0.12)))
        img.fill((b, b, b), special_flags=pygame.BLEND_RGB_MULT)
        if flash:
            img.fill((110, 110, 110), special_flags=pygame.BLEND_RGB_ADD)
        if alpha < 255:
            img.set_alpha(alpha)
        for x in range(max(0, left), min(RW, left + h), COLW):
            if depth < self.depth[min(NRAYS - 1, x // COLW)]:
                self.view.blit(img, (x, top), (x - left, 0, COLW, h))

    def draw_sprites(self):
        p = self.pl
        items = []
        t = pygame.time.get_ticks() / 1000
        for e in self.enemies:
            if not e.dead:
                items.append((e.x, e.y, self.spr[e.kind], e.scale, "floor", 255, e.hurt > 0, 0.03 * math.sin(e.t * 3) + 0.05))
        for pk in self.pickups:
            items.append((pk["x"], pk["y"], self.spr[pk["kind"]], 0.5, "floor", 255, False, 0.08 + 0.05 * math.sin(t * 3)))
        if self.portal and self.cleared:
            items.append((self.portal[0], self.portal[1], self.spr["portal"], 0.95, "floor", 255, False, 0.0))
        for q in self.projs:
            items.append((q["x"], q["y"], self.spr[q["kind"]], 0.8 if q["kind"] == "sphere" else 0.35, "mid", 255, False, 0.0))
        for f in self.effects:
            k = f["t"] / f["dur"]
            g = self.glow(f["col"])
            items.append((f["x"], f["y"], g, f["size"] * (0.3 + f["grow"] * k), "mid", int(255 * (1 - k)), False, 0.0))
        items.sort(key=lambda it: -((it[0] - p.x) ** 2 + (it[1] - p.y) ** 2))
        for it in items:
            self.billboard(it[2], it[0], it[1], it[3], it[4], it[5], it[6], it[7])

    def draw_hand(self):
        v = self.view
        bob = math.sin(self.walk) * 5
        rec = self.recoil * 40
        cx, cy = RW // 2 + 60 + bob * 0.6, RH - 30 + abs(bob) + rec
        pulse = 1 + 0.15 * math.sin(pygame.time.get_ticks() / 120)
        sleeve = [(cx + 40, RH), (cx - 30, RH), (cx - 12, cy + 4), (cx + 22, cy + 4)]
        pygame.draw.polygon(v, (25, 40, 90), sleeve)
        pygame.draw.polygon(v, (230, 235, 255), sleeve, 2)
        pygame.draw.circle(v, (240, 200, 170), (int(cx + 5), int(cy - 6)), 15)       # fist
        pygame.draw.rect(v, (240, 240, 250), (int(cx - 10), int(cy - 2), 30, 8))      # bandage
        g = self.glow((90, 200, 255))
        size = int((70 + self.recoil * 220) * pulse)
        gs = pygame.transform.scale(g, (size, size))
        v.blit(gs, (int(cx + 5 - size / 2), int(cy - 30 - size / 2)), special_flags=pygame.BLEND_RGB_ADD)

    # ---------------------------------------------------------------- HUD
    def draw_hud(self, scr):
        f, fm = self.f_s, self.f_m

        def bar(x, y, w, h, val, col, label):
            pygame.draw.rect(scr, (10, 10, 20), (x - 3, y - 3, w + 6, h + 6), border_radius=4)
            pygame.draw.rect(scr, col, (x, y, int(w * max(0, min(1, val / 100))), h), border_radius=3)
            scr.blit(f.render(label, True, (255, 255, 255)), (x + 8, y + 2))

        bar(24, SH - 90, 260, 18, self.hp, (220, 50, 70), "HP  %d" % self.hp)
        bar(24, SH - 62, 260, 14, self.energy, (60, 150, 255), "AETHER")
        ready = self.awk >= 100
        bar(24, SH - 38, 260, 14, self.awk, (255, 210, 70) if not ready else (255, 250, 160),
            "AWAKENING  READY - press 3 / R" if ready else "AWAKENING")

        icons = [("LMB", "Blast", True), ("1", "Void", self.energy >= 30 and self.cd["sphere"] <= 0),
                 ("2", "Mirage", self.energy >= 25 and self.cd["mirage"] <= 0), ("3", "DAWN", ready)]
        for i, (key, name, ok) in enumerate(icons):
            x = SW // 2 - 150 + i * 78
            pygame.draw.rect(scr, (16, 16, 32) if ok else (40, 40, 50), (x, SH - 74, 70, 56), border_radius=8)
            pygame.draw.rect(scr, (120, 200, 255) if ok else (90, 90, 100), (x, SH - 74, 70, 56), 2, border_radius=8)
            scr.blit(f.render("[" + key + "]", True, (255, 230, 120)), (x + 6, SH - 68))
            scr.blit(f.render(name, True, (255, 255, 255) if ok else (130, 130, 140)), (x + 6, SH - 40))

        L = LEVELS[self.idx]
        scr.blit(fm.render(L["name"], True, (255, 255, 255)), (20, 16))
        left = sum(1 for e in self.enemies if not e.dead)
        obj = ("Enter the LIGHT PORTAL!" if self.portal else "The Hollow Emperor falls!") if self.cleared else \
              ("Defeat the Hollow Emperor" if self.idx == 2 else "Shades remaining: %d" % left)
        scr.blit(fm.render(obj, True, (255, 220, 120)), (20, 44))

        boss = next((e for e in self.enemies if e.kind == "boss" and not e.dead and e.aware), None)
        if boss:
            w = 420
            pygame.draw.rect(scr, (10, 0, 10), (SW // 2 - w // 2 - 3, 12, w + 6, 20))
            pygame.draw.rect(scr, (200, 20, 60), (SW // 2 - w // 2, 15, int(w * boss.hp / boss.maxhp), 14))
            lbl = f.render("REN KUROGANE - THE HOLLOW EMPEROR", True, (255, 255, 255))
            scr.blit(lbl, (SW // 2 - lbl.get_width() // 2, 34))

        # minimap
        ts = 6
        mx0, my0 = SW - self.mw * ts - 14, 14
        pygame.draw.rect(scr, (0, 0, 0), (mx0 - 3, my0 - 3, self.mw * ts + 6, self.mh * ts + 6))
        for y in range(self.mh):
            for x in range(self.mw):
                if self.grid[y][x] in WALLS:
                    pygame.draw.rect(scr, (110, 110, 150), (mx0 + x * ts, my0 + y * ts, ts, ts))
        for e in self.enemies:
            if not e.dead:
                pygame.draw.circle(scr, (255, 60, 80), (int(mx0 + e.x * ts), int(my0 + e.y * ts)), 2)
        if self.portal and self.cleared:
            pygame.draw.circle(scr, (120, 240, 255), (int(mx0 + self.portal[0] * ts), int(my0 + self.portal[1] * ts)), 3)
        px, py = mx0 + self.pl.x * ts, my0 + self.pl.y * ts
        pygame.draw.circle(scr, (90, 255, 140), (int(px), int(py)), 3)
        pygame.draw.line(scr, (90, 255, 140), (px, py), (px + math.cos(self.pl.a) * 8, py + math.sin(self.pl.a) * 8))

        # crosshair
        pygame.draw.circle(scr, (255, 255, 255), (SW // 2, SH // 2), 3, 1)
        pygame.draw.line(scr, (140, 220, 255), (SW // 2 - 10, SH // 2), (SW // 2 - 5, SH // 2))
        pygame.draw.line(scr, (140, 220, 255), (SW // 2 + 5, SH // 2), (SW // 2 + 10, SH // 2))

        # dialogue
        if self.msg:
            who, text, _ = self.msg
            box = pygame.Surface((SW - 260, 62), pygame.SRCALPHA)
            box.fill((5, 5, 20, 190))
            scr.blit(box, (130, SH - 170))
            col = (255, 100, 120) if who == "Ren" else (120, 210, 255)
            scr.blit(fm.render(who, True, col), (146, SH - 164))
            scr.blit(f.render(text, True, (255, 255, 255)), (146, SH - 138))

        # ability callout
        if self.banner:
            txt, t, dur = self.banner
            img = self.f_l.render(txt, True, (255, 240, 170))
            k = t / dur
            img.set_alpha(int(255 * min(1, k * 2)))
            scr.blit(img, (SW // 2 - img.get_width() // 2, 110))

        if self.dmg_flash > 0:
            o = pygame.Surface((SW, SH), pygame.SRCALPHA)
            o.fill((255, 0, 20, int(140 * self.dmg_flash / 0.35)))
            scr.blit(o, (0, 0))
        if self.ult_flash > 0:
            o = pygame.Surface((SW, SH), pygame.SRCALPHA)
            o.fill((255, 255, 230, int(230 * self.ult_flash)))
            scr.blit(o, (0, 0))


# --------------------------------------------------------------------------
# Anime-style story screens
# --------------------------------------------------------------------------
def draw_hero(scr, x, y, sc, t):
    col = (6, 5, 12)
    pygame.draw.polygon(scr, col, [(x - 15 * sc, y), (x - 10 * sc, y - 52 * sc), (x + 10 * sc, y - 52 * sc), (x + 15 * sc, y)])
    pygame.draw.circle(scr, col, (int(x), int(y - 64 * sc)), int(11 * sc))
    for dx in (-10, -4, 3, 9):                                                    # spiky hair
        pygame.draw.polygon(scr, col, [(x + (dx - 4) * sc, y - 70 * sc), (x + (dx + 4) * sc, y - 70 * sc), (x + (dx + 2) * sc, y - 92 * sc)])
    w = math.sin(t * 3) * 6 * sc                                                  # scarf
    pygame.draw.polygon(scr, (170, 30, 50), [(x - 8 * sc, y - 54 * sc), (x + 8 * sc, y - 54 * sc), (x - 40 * sc, y - 46 * sc + w), (x - 44 * sc, y - 56 * sc + w)])
    pygame.draw.circle(scr, (120, 220, 255), (int(x - 4 * sc), int(y - 65 * sc)), max(1, int(2 * sc)))
    pygame.draw.circle(scr, (120, 220, 255), (int(x + 4 * sc), int(y - 65 * sc)), max(1, int(2 * sc)))


def draw_backdrop(scr, kind, t):
    W, H = scr.get_size()
    pal = SKIES[kind]
    for y in range(0, H, 4):
        pygame.draw.rect(scr, lerp(pal["top"], pal["bot"], (y / H) ** 1.3), (0, y, W, 4))
    rnd = random.Random(kind + 11)
    for _ in range(150):
        x, y = rnd.randrange(W), rnd.randrange(int(H * 0.7))
        b = int(150 + 90 * math.sin(t * 2 + x))
        scr.set_at((x, y), (b, b, b))
    mx, my = int(W * 0.72), int(H * 0.27)
    if pal["eclipse"]:
        for rad, col in ((120, (70, 0, 16)), (100, (150, 10, 35)), (86, (255, 90, 70))):
            pygame.draw.circle(scr, col, (mx, my), rad)
        pygame.draw.circle(scr, (0, 0, 0), (mx, my), 80)
    else:
        pygame.draw.circle(scr, lerp(pal["moon"], pal["bot"], 0.6), (mx, my), 100)
        pygame.draw.circle(scr, pal["moon"], (mx, my), 78)
    pygame.draw.polygon(scr, (8, 6, 14), [(0, H), (0, H * 0.82), (W * 0.25, H * 0.76), (W * 0.55, H * 0.84), (W * 0.8, H * 0.78), (W, H * 0.83), (W, H)])
    if kind == 0:                                                                 # torii gate
        gx, gy = W * 0.45, H * 0.80
        pygame.draw.rect(scr, (120, 16, 26), (gx - 90, gy - 150, 16, 150))
        pygame.draw.rect(scr, (120, 16, 26), (gx + 74, gy - 150, 16, 150))
        pygame.draw.rect(scr, (140, 20, 30), (gx - 115, gy - 165, 230, 18))
        pygame.draw.rect(scr, (140, 20, 30), (gx - 95, gy - 125, 190, 10))
    elif kind == 1:                                                               # crystal spikes
        for i in range(9):
            bx = W * (0.35 + i * 0.07)
            hh = 60 + (i * 53) % 110
            pygame.draw.polygon(scr, (60, 40, 120), [(bx - 18, H * 0.82), (bx, H * 0.82 - hh), (bx + 18, H * 0.82)])
    else:                                                                         # the Hollow Emperor
        vx, vy = W * 0.74, H * 0.84
        pygame.draw.polygon(scr, (0, 0, 0), [(vx - 40, vy), (vx - 26, vy - 150), (vx + 26, vy - 150), (vx + 40, vy)])
        pygame.draw.circle(scr, (0, 0, 0), (int(vx), int(vy - 165)), 17)
        for dx in (-14, -5, 5, 14):
            pygame.draw.polygon(scr, (0, 0, 0), [(vx + dx - 4, vy - 175), (vx + dx + 4, vy - 175), (vx + dx, vy - 205)])
        pygame.draw.circle(scr, (255, 30, 50), (int(vx - 6), int(vy - 165)), 3)
        pygame.draw.circle(scr, (255, 30, 50), (int(vx + 6), int(vy - 165)), 3)
    draw_hero(scr, W * 0.2, H * 0.82, 1.6, t)


def story_screen(g, title, pages, kind):
    scr, clock = g.screen, pygame.time.Clock()
    pygame.event.set_grab(False)
    pygame.mouse.set_visible(True)
    fb, fm, fs = pygame.font.Font(None, 30), g.f_m, g.f_s
    t = 0.0
    for page in pages:
        shown, adv = 0.0, False
        while not adv:
            dt = clock.tick(60) / 1000
            t += dt
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
                    return
                touch_advance = ev.type in (pygame.FINGERDOWN, pygame.MOUSEBUTTONDOWN)
                if (ev.type == pygame.KEYDOWN and ev.key in (pygame.K_RETURN, pygame.K_SPACE)) or touch_advance:
                    if shown < len(page):
                        shown = len(page)
                    else:
                        adv = True
            shown = min(len(page), shown + 55 * dt)
            draw_backdrop(scr, kind, t)
            box = pygame.Surface((SW - 120, 262), pygame.SRCALPHA)
            box.fill((4, 4, 16, 205))
            scr.blit(box, (60, SH - 292))
            pygame.draw.rect(scr, (120, 200, 255), (60, SH - 292, SW - 120, 262), 2, border_radius=6)
            scr.blit(fm.render(title, True, (255, 220, 120)), (84, SH - 280))
            left = int(shown)
            y = SH - 242
            for line in wrap(fb, page, SW - 170):
                scr.blit(fb.render(line[:max(0, left)], True, (255, 255, 255)), (84, y))
                left -= len(line) + 1
                y += 28
            if shown >= len(page) and int(t * 2) % 2 == 0:
                scr.blit(fs.render("ENTER / click to continue     (Esc: skip)", True, (170, 220, 255)), (SW - 350, SH - 24))
            pygame.display.flip()


def title_screen(g):
    scr, clock, t = g.screen, pygame.time.Clock(), 0.0
    while True:
        t += clock.tick(60) / 1000
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return False
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    return False
                if ev.key in (pygame.K_RETURN, pygame.K_SPACE):
                    return True
            if ev.type in (pygame.FINGERDOWN, pygame.MOUSEBUTTONDOWN):
                return True
        draw_backdrop(scr, 2, t)
        big = pygame.font.Font(None, 130).render("AETHER DAWN", True, (255, 245, 200))
        sub = pygame.font.Font(None, 54).render("- Hollow Eclipse -", True, (255, 110, 130))
        scr.blit(big, (SW // 2 - big.get_width() // 2, 70))
        scr.blit(sub, (SW // 2 - sub.get_width() // 2, 170))
        lines = ["W A S D  move    Mouse  look    Shift  sprint",
                 "Click / Space  Spirit Blast     1 / Right-click  Void Sphere",
                 "2 / E  Mirage Clones     3 / R  LIMITLESS DAWN (ultimate)"]
        for i, ln in enumerate(lines):
            s = g.f_s.render(ln, True, (220, 235, 255))
            scr.blit(s, (SW // 2 - s.get_width() // 2, 250 + i * 24))
        if int(t * 2) % 2 == 0:
            s = g.f_m.render("PRESS ENTER TO BEGIN", True, (255, 255, 255))
            scr.blit(s, (SW // 2 - s.get_width() // 2, 340))
        pygame.display.flip()


# --------------------------------------------------------------------------
# Main loops
# --------------------------------------------------------------------------
def run_level(g, clock):
    controls = TouchControls(SW, SH)
    paused = False
    android_touch = True
    while True:
        dt = min(clock.tick(60) / 1000, 0.05)
        rel = 0.0
        action = None
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return "quit"
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    paused = not paused
                elif g.state == "dead" and ev.key in (pygame.K_RETURN, pygame.K_r):
                    g.retry()
                elif not paused:
                    if ev.key == pygame.K_1:
                        g.cast_sphere()
                    elif ev.key in (pygame.K_2, pygame.K_e):
                        g.cast_mirage()
                    elif ev.key in (pygame.K_3, pygame.K_r):
                        g.cast_ult()
            elif ev.type == pygame.MOUSEBUTTONDOWN and not paused:
                if ev.button == 1:
                    controls.firing = True
                elif ev.button == 3:
                    g.cast_sphere()
            elif ev.type == pygame.MOUSEBUTTONUP:
                if ev.button == 1:
                    controls.firing = False
            elif ev.type == pygame.MOUSEMOTION and not paused:
                # Desktop mouse look remains available.
                rel += ev.rel[0]
            elif ev.type == pygame.FINGERDOWN:
                tid = getattr(ev, "finger_id", 0)
                pos = controls.pos(ev)
                if g.state == "dead":
                    g.retry()
                    paused = False
                    controls.touch_up(tid)
                    continue
                action = controls.touch_down(tid, pos)
                if action == "sphere" and not paused:
                    g.cast_sphere()
                elif action == "mirage" and not paused:
                    g.cast_mirage()
                elif action == "ult" and not paused:
                    g.cast_ult()
                elif action == "pause":
                    paused = not paused
                elif action == "blast" and not paused:
                    controls.firing = True
            elif ev.type == pygame.FINGERMOTION and not paused:
                tid = getattr(ev, "finger_id", 0)
                pos = controls.pos(ev)
                controls.touch_motion(tid, pos)
            elif ev.type == pygame.FINGERUP:
                controls.touch_up(getattr(ev, "finger_id", 0))

        if not paused:
            rel += controls.look_delta
            controls.look_delta = 0.0
            firing = controls.firing or pygame.mouse.get_pressed()[0]
            g.update(dt, controls.keys, rel, firing)
            if g.state == "clear":
                return "next"
        else:
            controls.look_delta = 0.0

        g.render()
        scr = g.screen
        scr.blit(pygame.transform.scale(g.view, (SW, SH)), (0, 0))
        g.draw_hud(scr)
        controls.draw(scr, g.f_s)
        if g.state == "dead":
            o = pygame.Surface((SW, SH), pygame.SRCALPHA)
            o.fill((20, 0, 0, 170))
            scr.blit(o, (0, 0))
            for txt, fnt, y in (("YOU FELL... BUT THE DAWN ISN'T OVER", g.f_l, SH // 2 - 50),
                                ("Press ENTER or tap to rise again", g.f_m, SH // 2 + 20)):
                s = fnt.render(txt, True, (255, 230, 230))
                scr.blit(s, (SW // 2 - s.get_width() // 2, y))
        if paused:
            o = pygame.Surface((SW, SH), pygame.SRCALPHA)
            o.fill((0, 0, 20, 190))
            scr.blit(o, (0, 0))
            for i, txt in enumerate(["PAUSED", "Tap II to resume", "Left joystick move | Drag right side look",
                                     "BLAST | VOID | MIRAGE | DAWN"]):
                s = (g.f_l if i == 0 else g.f_m).render(txt, True, (255, 255, 255))
                scr.blit(s, (SW // 2 - s.get_width() // 2, 200 + i * 50))
        pygame.display.flip()


def main():
    pygame.init()
    pygame.display.set_caption("AETHER DAWN - Hollow Eclipse")
    # Logical 1024x640 canvas, scaled to the device in landscape mode.
    screen = pygame.display.set_mode((SW, SH), pygame.SCALED | pygame.FULLSCREEN)
    clock = pygame.time.Clock()
    g = Game(screen)
    if not title_screen(g):
        pygame.quit()
        return
    story_screen(g, "PROLOGUE: The Boy Called Powerless", PROLOGUE, 0)
    for i, L in enumerate(LEVELS):
        story_screen(g, L["name"], L["intro"], L["sky"])
        g.load_level(i)
        if run_level(g, clock) == "quit":
            pygame.quit()
            return
    story_screen(g, "EPILOGUE: A New Dawn", ENDING, 0)
    pygame.quit()


if __name__ == "__main__":
    main()