# AETHER DAWN: Hollow Eclipse — Android Project

This folder contains an Android-ready version of the original Pygame game.

## What was changed

- Kept the original 2.5D raycasting engine, story, chapters, enemies, boss, powers, and procedural graphics.
- Added a landscape Android display using a 1024×640 logical canvas scaled to the phone screen.
- Added a virtual left joystick for movement/strafe.
- Added right-side drag camera/look control.
- Added touch buttons for BLAST, VOID, MIRAGE, DAWN (ultimate), RUN, and pause.
- Story/title screens accept taps.
- Desktop keyboard/mouse controls remain available for testing.
- No external image assets are required by the game itself.

## Build on Windows/Linux/macOS

The easiest route is Buildozer inside a Linux environment (Ubuntu/WSL is commonly used on Windows).

### 1. Install Buildozer dependencies

Use the current Buildozer/python-for-android installation instructions for your Linux distribution, then install Buildozer.

### 2. Enter this project

```bash
cd AetherDawn_Android
```

### 3. Test the Python game on desktop

```bash
python3 -m pip install pygame
python3 main.py
```

### 4. Build a debug APK

```bash
buildozer android debug
```

The generated APK will be placed in the `bin/` directory.

### 5. Install on an Android phone

With USB debugging enabled:

```bash
buildozer android deploy run
```

Or copy the APK from `bin/` to the phone and install it manually.

## Important build note

This chat environment can prepare the Android project, but a successful APK build requires the Android SDK/NDK/Gradle toolchain used by Buildozer/python-for-android. The project is therefore supplied as a ready-to-build source project rather than claiming that an APK was compiled here.

## Files

- `main.py` — Android-adapted game
- `aether_dawn_original.py` — original uploaded source preserved unchanged
- `buildozer.spec` — Android build configuration
- `README_ANDROID.md` — build and installation instructions
